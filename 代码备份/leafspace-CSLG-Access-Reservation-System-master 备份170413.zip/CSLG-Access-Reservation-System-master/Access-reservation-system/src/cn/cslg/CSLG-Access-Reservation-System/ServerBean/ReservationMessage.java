package cn.cslg.CSLGAccessReservationSystem.ServerBean;

import cn.cslg.CSLGAccessReservationSystem.QR_CodeSupport.CreateParseCode;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by 18852 on 2017/3/17.
 */
public class ReservationMessage {
    public String reservation_id = null;                                      //预约id
    public User user = null;                                                  //用户名
    public ActivityRoom room = null;                                          //活动室类
    public Time time = null;                                                  //时间类
    public boolean isValid = true;                                            //判定是否有效
    public boolean isLock = false;                                            //判断此预约消息是否为管理员的锁定操作
    public String qr_location = null;                                         //二维码路径
    public String information = null;                                         //预约信息

    public ReservationMessage(String reservation_id) {
        this.reservation_id = reservation_id;
        this.getDataFromDatabase(reservation_id);
    }

    public ReservationMessage(User user, ActivityRoom room, Time time, boolean isValid, boolean isLock) {
        this.user = user;
        this.room = room;
        this.time = time;
        this.isValid = isValid;
        this.isLock = isLock;
    }

    public ReservationMessage(User user, ActivityRoom room, Time time, boolean isValid, boolean isLock, String information) {
        this.user = user;
        this.room = room;
        this.time = time;
        this.isValid = isValid;
        this.isLock = isLock;
        this.information = information;
    }
    public ReservationMessage(String reservation_id, User user, ActivityRoom room, Time time, boolean isValid, boolean isLock, String qr_location, String information) {
        this.reservation_id = reservation_id;
        this.user = user;
        this.room = room;
        this.time = time;
        this.isValid = isValid;
        this.isLock = isLock;
        this.qr_location = qr_location;
        this.information = information;
    }

    public void getDataFromDatabase(String reservation_id) {
        DBSqlServerConnection dbSqlServerConnection = new DBSqlServerConnection();
        String sql = "SELECT * FROM Reservations WHERE reservation_Id = '" + reservation_id + "';";
        dbSqlServerConnection.getPstmt(sql);
        ResultSet resultSet = dbSqlServerConnection.query();
        try{
            while(resultSet != null & resultSet.next()){
                this.reservation_id = resultSet.getString(1);
                this.user = new User(resultSet.getString(2));
                this.room = new ActivityRoom(resultSet.getString(3));
                this.isValid = resultSet.getBoolean(4);
                this.isLock = resultSet.getBoolean(5);
                this.time = new Time(resultSet.getInt(6), resultSet.getInt(7), resultSet.getInt(8), resultSet.getInt(9),
                        resultSet.getInt(10));
                this.qr_location = resultSet.getString(11);
                this.information = resultSet.getString(12);
                break;
            }
        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            dbSqlServerConnection.allClose();
        }
    }

    public void CreateQrCodes() {
        CreateParseCode cpCode = new CreateParseCode();
        //Todo 转义信息

        String information = "";
        cpCode.createCode(information, CreateParseCode.width, CreateParseCode.height, this.qr_location);
    }

    public void ExplainQrCodes() {
        CreateParseCode cpCode = new CreateParseCode();
        cpCode.parseCode(new File(this.qr_location));
    }
}
