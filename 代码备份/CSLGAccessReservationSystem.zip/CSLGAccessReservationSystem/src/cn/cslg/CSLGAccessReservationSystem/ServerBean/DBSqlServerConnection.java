package cn.cslg.CSLGAccessReservationSystem.ServerBean;

/**
 * Created by 18852 on 2017/3/17.
 */

import java.sql.*;

/**
 *  Java连接DB，实现DB先关操作工具类
 * 	JDBC - Java Data Base Connectivity
 * 		1: 加入数据库驱动jar包   copy至WEB-INF下的lib中
 * 		2: 获取数据库链接
 * 		3: 获取语句处理
 * 		4: 实现数据ARUD操作
 * 		5: 关闭数据库相关操作
 */
public class DBSqlServerConnection {
    private static int port = 1433;                                            //端口号
    private static String databaseName = "CSLG_Access_reservation_system";     //数据库名
    private static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";   //驱动名
    private static String userName = "sa";                                     //用户名    注：要修改
    private static String password = "zta19960503";                                 //密码      注：要修改

    private Connection connection = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
    /**
     * 获取数据库链接
     */
    private void getConnection() {
        String dbURL = "jdbc:sqlserver://localhost:" + DBSqlServerConnection.port +";databasename=" + DBSqlServerConnection.databaseName;
        try {
            Class.forName(driverName).newInstance();
            this.connection = DriverManager.getConnection(dbURL, DBSqlServerConnection.userName, DBSqlServerConnection.password);
            System.out.println("Info (Database) : Sql Server 驱动加载成功 !");
        } catch (Exception e) {
            System.out.println("Info (Database) : Sql Server 驱动加载失败 !");
            e.printStackTrace();
        }
    }

    private  boolean isConnection() {
        if(this.connection == null){
            return false;
        }else{
            return true;
        }
    }

    public DBSqlServerConnection() {
    }

    public DBSqlServerConnection(String userName, String password) {
        DBSqlServerConnection.userName = userName;
        DBSqlServerConnection.password = password;
    }

    /**
     * 获取语句处理 PreparedStatement
     */
    public PreparedStatement getPstmt(String sql) {
        this.getConnection();
        try {
            this.preparedStatement = this.connection.prepareStatement(sql);
            System.out.println("Info (Database) : Sql - " + sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return this.preparedStatement;
    }

    /**
     * 实现数据库更新操作
     * 	insert、update、delete
     */
    public void update() {
        if(!this.isConnection()){
            System.out.println("Error (Database) : Sql Server 未连接 !");
            return ;
        }

        try {
            this.preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * 实现数据库查询操作
     * 	select
     */
    public ResultSet query() {
        if(!this.isConnection()){
            System.out.println("Error (Database) : Sql Server 未连接 !");
            return null;
        }

        try {
           this.resultSet = this.preparedStatement.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return this.resultSet;
    }

    /**
     * 关闭数据库相关操作
     */
    public void allClose() {
        if(this.resultSet != null) {
            try {
                this.resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        if(this.preparedStatement != null) {
            try {
                this.preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        if(this.connection != null) {
            try {
               this.connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
