package cn.cslg.CSLGAccessReservationSystem.LocalServer;

import cn.cslg.CSLGAccessReservationSystem.ServerBean.ActivityRoom;
import cn.cslg.CSLGAccessReservationSystem.ServerBean.Manager;
import cn.cslg.CSLGAccessReservationSystem.ServerBean.User;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;



/**
 * Created by Administrator on 2017/3/22.
 */
public class QueryAllActivityRoomServlet extends HttpServlet{
     Manager manager;
     User user;
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        response.setCharacterEncoding("utf-8");//设置 编码格式
        user=(User)request.getSession().getAttribute("user");
        manager=(Manager)request.getSession().getAttribute("manager");
        
        //User userSession = new User("5");//定义一个用户以供测试
        
        ArrayList<ActivityRoom> activityRooms = null;
        String flag = request.getParameter("flag");
        
        System.out.println(flag);
        System.out.println(manager);
        if(manager!=null){
            activityRooms=manager.queryAllRooms();
            System.out.println(activityRooms);
        }else{
            activityRooms = user.queryAllRooms();
        }
        
        boolean isSuccessed;
        
        if(activityRooms==null){
            System.out.println("执行到这！");
            isSuccessed=false;
            PrintWriter pw = response.getWriter();
            pw.print(isSuccessed);
            pw.close();
        }else{
            System.out.println("执行到这——allUsers");
            JSONArray jsonArray=arrayListToJSONArray(activityRooms);
            PrintWriter pw = response.getWriter();
            pw.print(jsonArray.toString());
            pw.close();
        }
        
        
       /* if(request.getSession().getAttribute("user") != null){                 //普通用户查询活动室预约信息操作
            //userSession = (User) request.getSession().getAttribute("user");
            activityRooms = userSession.queryAllRooms();
        }else{                                                                    //管理员查询活动室预约信息操作
            managerSession = (Manager) request.getSession().getAttribute("manager");
            activityRooms = managerSession.queryAllRooms();
        }*/
        
       /* request.setAttribute("activityRooms", activityRooms);
        request.setAttribute("user",userSession);*/
        //request.getRequestDispatcher("page2.html").forward(request, response);          //跳转至相应网页
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request,response);
    }
    
      /**
     * ArrayList<ActivityRoom>转换为Json
     */
    public JSONArray arrayListToJSONArray( ArrayList<ActivityRoom> activityRooms){  
        
        ActivityRoom activityRoom;
        JSONArray jsonArray = new JSONArray();
        Iterator i=activityRooms.iterator();
        while(i.hasNext()){
            activityRoom=(ActivityRoom)i.next();
            JSONObject jsonObject=new JSONObject();
            jsonObject.put("room_id",activityRoom.room_id);
            jsonObject.put("room_name",activityRoom.room_name);
            jsonObject.put("information",activityRoom.information);
            jsonArray.add(jsonObject);
        }
        return jsonArray;
    }
}
