package cn.cslg.CSLGAccessReservationSystem.LocalServer;

import cn.cslg.CSLGAccessReservationSystem.ServerBean.Manager;
import cn.cslg.CSLGAccessReservationSystem.ServerBean.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


/**
 * Created by Administrator on 2017/3/22.
 */
public class DeleteReservationServlet extends HttpServlet {
    Manager manager ;
    User user;
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        manager = (Manager) request.getSession().getAttribute("manager");        //获取session中的manager对象
        user=(User) request.getSession().getAttribute("user");
        String reservation_id = request.getParameter("reservation_id");

        if(manager==null&&user!=null){
            manager=new Manager(user.getUserID());
        }
        
        boolean isSuccessed;
        isSuccessed=manager.deleteReservation(reservation_id);
        PrintWriter pw = response.getWriter();
        pw.print(isSuccessed);
        pw.close();
        //request.getRequestDispatcher("?").forward(request, response);          //跳转至相应网页
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request,response);
    }
}
