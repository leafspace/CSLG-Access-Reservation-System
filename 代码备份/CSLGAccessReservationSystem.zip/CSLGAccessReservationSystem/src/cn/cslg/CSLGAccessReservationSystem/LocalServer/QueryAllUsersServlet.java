package cn.cslg.CSLGAccessReservationSystem.LocalServer;

import cn.cslg.CSLGAccessReservationSystem.ServerBean.Manager;
import cn.cslg.CSLGAccessReservationSystem.ServerBean.ReservationMessage;
import cn.cslg.CSLGAccessReservationSystem.ServerBean.User;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * Created by Administrator on 2017/3/21.
 */
public class QueryAllUsersServlet extends HttpServlet{
    private Manager manager;
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        response.setCharacterEncoding("utf-8");//设置 编码格式
        manager = (Manager) request.getSession().getAttribute("manager");        //获取session中的manager对象
        
        System.out.println(manager.getUsername());
        //manager=new Manager("詹太安","123456");
        
        ArrayList<User> users = null;
        users = manager.queryAllUsers();
        
        
        boolean isSuccessed;
        
        if(users==null){
            System.out.println("执行到这！");
            isSuccessed=false;
            PrintWriter pw = response.getWriter();
            pw.print(isSuccessed);
            pw.close();
        }else{
            System.out.println("执行到这——allUsers");
            JSONArray jsonArray=arrayListToJSONArray(users);
            PrintWriter pw = response.getWriter();
            pw.print(jsonArray.toString());
            pw.close();
        }
        /*request.setAttribute("users", users);
        request.getRequestDispatcher("?").forward(request, response);          //跳转至相应网页*/
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request,response);
    }
    
     /**
     * ArrayList<ReservationMessage>转换为Json
     */
     public JSONArray arrayListToJSONArray( ArrayList<User> users){  
        
        User user;
        JSONArray jsonArray = new JSONArray();
        Iterator i=users.iterator();
        while(i.hasNext()){
            user=(User)i.next();
            JSONObject jsonObject=new JSONObject();
            jsonObject.put("user_id",user.getUserID());
            jsonObject.put("username",user.getUserName());
            jsonObject.put("identity_number",user.getIdentityID());
            jsonArray.add(jsonObject);
        }
        return jsonArray;
    }
}
