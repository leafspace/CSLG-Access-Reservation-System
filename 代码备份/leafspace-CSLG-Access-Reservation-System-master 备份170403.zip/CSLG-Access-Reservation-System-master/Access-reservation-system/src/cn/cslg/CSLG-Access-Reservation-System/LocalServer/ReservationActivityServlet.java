package cn.cslg.CSLGAccessReservationSystem.LocalServer;

import cn.cslg.CSLGAccessReservationSystem.ServerBean.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Created by Administrator on 2017/3/21.
 */
public class ReservationActivityServlet extends HttpServlet{
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        //User userSession=(User)request.getSession().getAttribute("userSession");

        String room_id = request.getParameter("room_id");                      //获取输入的room_id
        User userSession=new User("5");//定义一个用户以供测试
        
        Time time = new Time(Integer.parseInt(request.getParameter("year")),
                Integer.parseInt(request.getParameter("month")),
                Integer.parseInt(request.getParameter("day")),
                getIntTime(request.getParameter("start")),
                getIntTime(request.getParameter("finish")));             //获取输入的time，年，月，日,开始，结束格式
        
        String information = request.getParameter("information");              //获取输入的备注信息

        ActivityRoom activity_room = new ActivityRoom(room_id);
        
        ReservationMessage reservationMessage = new ReservationMessage(userSession, activity_room, time, false,false, information);
        
        boolean isSuccessed=userSession.reservationActivityRoom(reservationMessage);
        PrintWriter pw = response.getWriter();
        pw.print(isSuccessed);
        pw.close();
        
        /*User userSession = null;
        Manager managerSession = null;
        if(request.getSession().getAttribute("user") != null){                 //普通用户预约操作
            userSession = (User) request.getSession().getAttribute("user");
            ReservationMessage reservationMessage = new ReservationMessage(userSession, activity_room, time, false,false, information);
            userSession.reservationActivityRoom(reservationMessage);
        }else{                                                                    //管理员预约操作
            managerSession = (Manager) request.getSession().getAttribute("manager");
            User user = new User(managerSession.getUser_id());
            ReservationMessage reservationMessage = new ReservationMessage(user, activity_room, time,true,true, information);
            managerSession.addReservation(reservationMessage);
        }*/
       // request.getRequestDispatcher("?").forward(request, response);          //跳转至相应网页
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request,response);
    }
    
    /**
     * 将交互层输入的时间数据转换成int类型时间数据，如08：00—>800 ，10：00—>1000
     * 返回类型为int 如 800,1000
     */
    public int getIntTime(String time) {
        int newTime;
        String tmpStr="";
        if(time.length()>0){
            for(int i=0;i<time.length();i++){
                    String tmp=""+time.charAt(i);
                    if((tmp).matches("[0-9.]")){
                            tmpStr+=tmp;
                    }
            }
        }
        newTime=Integer.parseInt(tmpStr);
        return newTime;
    }
}
