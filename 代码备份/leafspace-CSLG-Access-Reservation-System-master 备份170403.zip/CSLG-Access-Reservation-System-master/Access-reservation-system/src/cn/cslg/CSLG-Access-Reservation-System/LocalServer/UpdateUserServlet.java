package cn.cslg.CSLGAccessReservationSystem.LocalServer;

import cn.cslg.CSLGAccessReservationSystem.ServerBean.User;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Created by Administrator on 2017/3/21.
 */
public class UpdateUserServlet extends HttpServlet{
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        //User userSession=(User)request.getSession().getAttribute("userSession");

        String userName= request.getParameter("name");                         //用户名
        String phone_number = request.getParameter("phoneNum");                //手机号
        String identity_number =  request.getParameter("amount");              //教/工号
        String password = request.getParameter("password");                    //密码
        String information = request.getParameter("information");              //备注信息

        User user = new User("5");                                             //定义一个用户以供测试
        boolean isSuccessed=user.updateInformation(password, userName, phone_number, identity_number, information);
        PrintWriter pw = response.getWriter();
        pw.print(isSuccessed);
        pw.close();
        
        //request.getRequestDispatcher("?").forward(request, response);        //跳转至相应网页
        
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        doGet(request,response);
    }
}
