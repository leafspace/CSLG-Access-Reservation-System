#CSLG-Access-Reservation-System


软件项目分为四个部分;<br>
1.硬件控制端（面向管理）<br>
2.Web端-面向用户<br>
3.Web端-面向管理<br>
4.微信端<br>

文件目录如下<br>
    -Access-reservation-system<br>
        -src/cn/cslg/CSLG-Access-Reservation-System (类包)<br>
            -LocalServer（保存Servlet相关服务）<br>
            -ServerBean（保存工具类相关）<br>
            -WeChat（保存和擦偶哦微信客户端相关操作）<br>
    -常熟理工学院门禁预约系统<br>
        -常熟理工学院门禁预约系统（MFC操作控制源码）<br>
    -面向管理设计（保存相关设计图等）<br>